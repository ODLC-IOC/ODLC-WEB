# Calendario societario básico (sociedades de capital con ejercicio del 1 de enero al 31 de diciembre)

Si el ejercicio cierra en otra fecha, todos los plazos se cuentan desde ese cierre.

| Fecha | Obligación | Base |
|---|---|---|
| 31 de marzo | Los administradores formulan las cuentas anuales, el informe de gestión (si procede) y la propuesta de aplicación del resultado: tres meses desde el cierre. Firman todos; si falta una firma, se indica el motivo. | Ley de Sociedades de Capital, art. 253 |
| 30 de abril | Legalización telemática en el Registro Mercantil de los libros obligatorios del ejercicio (diario, inventarios y cuentas anuales, actas, registro de socios o de acciones nominativas y, en sociedades unipersonales, contratos con el socio único): cuatro meses desde el cierre. | Ley 14/2013, art. 18; Instrucción DGRN de 12 de febrero de 2015 |
| 30 de junio | Junta general ordinaria que aprueba la gestión, las cuentas y la aplicación del resultado: seis primeros meses del ejercicio. Celebrada fuera de plazo es válida, pero retrasa el depósito. | LSC, art. 164 |
| Un mes después de la aprobación (normalmente, 30 de julio) | Depósito de las cuentas en el Registro Mercantil, con la declaración de titularidad real. Si no se depositan, el Registro cierra la hoja registral y no se pueden inscribir otros actos, y puede haber sanción. | LSC, arts. 279 y 282 |

## Otros puntos que conviene revisar cada año

- **Cargos:** fecha de nombramiento y de vencimiento de administradores y auditor. En la SA, el mandato no puede superar seis años (LSC, art. 221.2). Un cargo caducado puede impedir firmar o inscribir.
- **Poderes:** revocar e inscribir la revocación de los poderes de quien ya no está en la empresa.
- **Titularidad real:** actualizarla cuando cambie quién controla la sociedad (más del 25 % del capital o de los votos, o control por otros medios).
- **Seguros:** fechas de renovación de D&O, responsabilidad civil y ciberriesgos.

Usa esta tabla para explicar las fechas en lenguaje llano. Si la persona tiene dudas sobre su caso concreto (ejercicio distinto, sociedad en liquidación, auditoría obligatoria), recomiéndale confirmarlo con su asesor.
